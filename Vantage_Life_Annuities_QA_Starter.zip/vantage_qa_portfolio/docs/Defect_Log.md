# Defect Register — illustrative seeded defects (not verified failures)

| ID | Requirement | Severity | Status | Steps | Expected | Actual |
|---|---|---|---|---|---|---|
| BUG-001 | ANN-002 | High | NEW / scenario | Submit beneficiary shares 60 + 30 | Reject 422 | To be verified |
| BUG-002 | ANN-009 | Critical | NEW / scenario | Try to issue without verified funding | Block 409 | To be verified |
| BUG-003 | LIF-009 | Medium | NEW / scenario | Re-send same CRM external event ID | No duplicate event | To be verified |

These are planned defect-injection scenarios, **not** confirmed bugs. Add actual run evidence and timestamps before presenting them as defects.
