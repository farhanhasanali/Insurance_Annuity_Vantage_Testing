# Four-day execution board

**Day 1:** Review both form packages; approve BRDs; initialize PostgreSQL schema; run SQL smoke checks.
**Day 2:** Run FastAPI; execute Postman CRUD and workflow tests; add realistic multi-source fixture events.
**Day 3:** Run pytest and database checks; log reproducible defects; add Selenium only if a web UI exists.
**Day 4:** Execute clean CI run; collect JUnit reports and screenshots; push to GitHub; publish accurate LinkedIn summary.

**Definition of done:** README reproduces setup; no real PII or proprietary PDFs committed; tests reproducible; open limitations listed.
