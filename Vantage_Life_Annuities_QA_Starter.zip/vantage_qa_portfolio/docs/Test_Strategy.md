# Vantage Test Strategy v1.0

## Scope
Synthetic life and annuity applications, validation, status transitions, multi-source ingestion, reconciliation and audit.

## Test levels
- Unit: pure validation and premium reconciliation.
- API: happy path, required fields, negative values, state conflicts, idempotency, unknown records, bad source events.
- Database: constraints, FK integrity, event uniqueness, audit records, cross-source amounts.
- UI: Selenium smoke tests after a UI is added; no UI claimed in this MVP.
- Security: authorization, masked logging, invalid payloads; production-grade pen test out of scope.

## Entry/exit
Entry: database migrated, seeded demo data, API health 200. Exit: critical test scenarios pass, defects documented, open issues acknowledged.

## Automation
pytest + httpx + psycopg, Postman collection, PostgreSQL checks, GitHub Actions. Karate is an optional follow-on; not implemented in MVP.

## Defect workflow
NEW → TRIAGED → IN_PROGRESS → FIXED → RETEST → CLOSED / REOPENED. Record steps, actual/expected, severity, requirement and test ID.

## Evidence
`pytest -q --junitxml=reports/results.xml`; `psql -f db/qa_checks.sql`; Postman collection runner.
