# Source privacy and redaction policy

The two original application PDFs were reviewed **locally only** to identify fields and business processes. The original PDFs are excluded from the Git repository and distribution ZIP. The project contains no extracted filled customer records, handwritten signatures, SSNs or account numbers. All fixtures use synthetic names.

**Important:** The original uploaded PDFs have **not** been certified as fully redacted. Do not publish them. If a redacted copy is needed, perform verified permanent redaction of text, annotations, handwriting, embedded images, metadata and any hidden OCR layers; then inspect every page before release.

Carrier forms and product disclosures are historical examples, not reusable production specifications. This repository intentionally uses independent proposed requirements and fictional product codes.
