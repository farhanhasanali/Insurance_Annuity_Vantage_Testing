I built a Vantage-style Life & Annuities QA automation portfolio project to demonstrate the end-to-end testing workflow used in insurance technology.

Using synthetic applications modeled on real-world form structures, I designed separate life insurance and annuity business requirements, a PostgreSQL relational schema, a multi-source integration model, and a Python/FastAPI API with Postman and pytest test assets.

The project emphasizes beneficiary and premium validation, underwriting/suitability workflow controls, event idempotency, database reconciliation, requirement traceability, and defect reporting.

This is a **simulated training application**, not the proprietary Vantage platform or a production insurer integration.

[ADD: actual passing test counts, screenshots and GitHub link after running]

#QAEngineering #TestAutomation #LifeInsurance #Annuities #PostgreSQL #Python #APItesting #Postman
