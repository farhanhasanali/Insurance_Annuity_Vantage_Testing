"""Fictional Vantage application API. Requires PostgreSQL schema.sql."""
import os,uuid
from contextlib import contextmanager
from decimal import Decimal
import psycopg
from psycopg.rows import dict_row
from fastapi import FastAPI,HTTPException,Header
from pydantic import BaseModel,Field

DATABASE_URL=os.getenv('DATABASE_URL','postgresql://vantage:vantage_dev_only@localhost:5432/vantage')
app=FastAPI(title='Vantage Life & Annuities — QA Simulation',version='1.0.0')

@contextmanager
def db():
    with psycopg.connect(DATABASE_URL,row_factory=dict_row) as conn:
        yield conn

class Beneficiary(BaseModel):
    name:str=Field(min_length=1)
    category:str=Field(pattern='^(PRIMARY|CONTINGENT)$')
    share:Decimal=Field(gt=0,le=100)

class Application(BaseModel):
    app_type:str=Field(pattern='^(LIFE|ANNUITY)$')
    applicant_name:str=Field(min_length=2)
    product_code:str=Field(min_length=2)
    requested_amount:Decimal=Field(gt=0)
    tax_qualification:str|None=None
    beneficiaries:list[Beneficiary]=Field(min_length=1)

def validate_shares(beneficiaries):
    for group in ('PRIMARY','CONTINGENT'):
        shares=[b.share for b in beneficiaries if b.category==group]
        if group=='PRIMARY' and not shares:
            raise HTTPException(422,'At least one PRIMARY beneficiary is required')
        if shares and sum(shares)!=100:
            raise HTTPException(422,f'{group} beneficiary shares must total 100')

@app.get('/health')
def health():
    with db() as conn:
        conn.execute('SELECT 1')
    return {'status':'ok'}

@app.post('/applications',status_code=201)
def create_application(body:Application,x_correlation_id:str|None=Header(default=None)):
    validate_shares(body.beneficiaries)
    corr=x_correlation_id or str(uuid.uuid4())
    with db() as conn:
        row=conn.execute("""INSERT INTO applications(app_type,applicant_name,product_code,requested_amount,tax_qualification)
          VALUES(%s,%s,%s,%s,%s) RETURNING id,status""",(body.app_type,body.applicant_name,body.product_code,body.requested_amount,body.tax_qualification)).fetchone()
        for b in body.beneficiaries:
            conn.execute('INSERT INTO beneficiaries(application_id,beneficiary_name,beneficiary_class,share_pct) VALUES(%s,%s,%s,%s)',(row['id'],b.name,b.category,b.share))
        conn.execute('INSERT INTO audit_events(application_id,new_status,action,correlation_id) VALUES(%s,%s,%s,%s)',(row['id'],'DRAFT','CREATE',corr))
    return {'id':row['id'],'status':row['status'],'correlation_id':corr}

@app.get('/applications/{application_id}')
def get_application(application_id:int):
    with db() as conn:
        row=conn.execute('SELECT id,app_type,applicant_name,product_code,status,requested_amount,tax_qualification,suitability_approved,underwriting_approved,funding_verified FROM applications WHERE id=%s',(application_id,)).fetchone()
        if not row:raise HTTPException(404,'Application not found')
        row['beneficiaries']=conn.execute('SELECT beneficiary_name,beneficiary_class,share_pct FROM beneficiaries WHERE application_id=%s ORDER BY id',(application_id,)).fetchall()
        return row

class Decision(BaseModel):
    approved:bool
    decision_type:str=Field(pattern='^(SUITABILITY|UNDERWRITING|FUNDING)$')

@app.post('/applications/{application_id}/decisions')
def record_decision(application_id:int,body:Decision):
    with db() as conn:
        row=conn.execute('SELECT app_type,status FROM applications WHERE id=%s FOR UPDATE',(application_id,)).fetchone()
        if not row:raise HTTPException(404,'Application not found')
        if row['status']=='ISSUED':raise HTTPException(409,'Issued applications are immutable')
        field={'SUITABILITY':'suitability_approved','UNDERWRITING':'underwriting_approved','FUNDING':'funding_verified'}[body.decision_type]
        if body.decision_type=='SUITABILITY' and row['app_type']!='ANNUITY':raise HTTPException(422,'Suitability applies to annuity')
        if body.decision_type=='UNDERWRITING' and row['app_type']!='LIFE':raise HTTPException(422,'Underwriting applies to life')
        conn.execute(f'UPDATE applications SET {field}=%s,updated_at=NOW() WHERE id=%s',(body.approved,application_id))
    return {'decision_type':body.decision_type,'approved':body.approved}

@app.post('/applications/{application_id}/transition')
def transition(application_id:int,target:str,x_correlation_id:str|None=Header(default=None)):
    transitions={'DRAFT':{'SUBMITTED'},'SUBMITTED':{'IN_REVIEW'},'IN_REVIEW':{'APPROVED','REJECTED'},'APPROVED':{'ISSUED'}}
    with db() as conn:
        row=conn.execute('SELECT * FROM applications WHERE id=%s FOR UPDATE',(application_id,)).fetchone()
        if not row:raise HTTPException(404,'Application not found')
        if target not in transitions.get(row['status'],set()):raise HTTPException(409,'Invalid status transition')
        if target=='APPROVED' and not row['suitability_approved' if row['app_type']=='ANNUITY' else 'underwriting_approved']:
            raise HTTPException(409,'Required review not approved')
        if target=='ISSUED' and not row['funding_verified']:raise HTTPException(409,'Funding not verified')
        conn.execute('UPDATE applications SET status=%s,updated_at=NOW() WHERE id=%s',(target,application_id))
        conn.execute('INSERT INTO audit_events(application_id,old_status,new_status,action,correlation_id) VALUES(%s,%s,%s,%s,%s)',(application_id,row['status'],target,'TRANSITION',x_correlation_id or str(uuid.uuid4())))
    return {'id':application_id,'status':target}

class SourceEvent(BaseModel):
    source_system:str=Field(pattern='^(CRM|AGENT_PORTAL|FUNDING|PRODUCT_CATALOG|REVIEW)$')
    external_event_id:str=Field(min_length=1)
    application_id:int|None=None
    event_type:str=Field(min_length=1)
    payload:dict

@app.post('/integrations/events',status_code=201)
def ingest_event(body:SourceEvent):
    from psycopg.types.json import Jsonb
    with db() as conn:
        row=conn.execute("""INSERT INTO inbound_events(source_system,external_event_id,application_id,event_type,payload) VALUES(%s,%s,%s,%s,%s) ON CONFLICT(source_system,external_event_id) DO NOTHING RETURNING id""",(body.source_system,body.external_event_id,body.application_id,body.event_type,Jsonb(body.payload))).fetchone()
        if not row:return {'status':'duplicate_ignored'}
        return {'status':'accepted','event_id':row['id']}
