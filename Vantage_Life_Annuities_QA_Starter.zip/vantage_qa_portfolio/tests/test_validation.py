from decimal import Decimal
from fastapi import HTTPException
from app.main import Beneficiary,validate_shares
import pytest

def test_valid_primary_allocation():
    validate_shares([Beneficiary(name='Synthetic A',category='PRIMARY',share=Decimal('60')),Beneficiary(name='Synthetic B',category='PRIMARY',share=Decimal('40'))])

@pytest.mark.parametrize('share',[Decimal('99'),Decimal('101')])
def test_invalid_primary_total(share):
    with pytest.raises((HTTPException,ValueError)):
        validate_shares([Beneficiary(name='Synthetic A',category='PRIMARY',share=share)])

def test_missing_primary():
    with pytest.raises(HTTPException):
        validate_shares([Beneficiary(name='Synthetic C',category='CONTINGENT',share=Decimal('100'))])
