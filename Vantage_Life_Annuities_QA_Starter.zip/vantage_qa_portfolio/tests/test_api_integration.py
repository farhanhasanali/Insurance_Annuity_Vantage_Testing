"""Run with VANTAGE_RUN_INTEGRATION=1 and a live Postgres + API server."""
import os,uuid
import pytest,httpx
pytestmark=pytest.mark.skipif(os.getenv('VANTAGE_RUN_INTEGRATION')!='1',reason='Opt-in live integration test')
BASE=os.getenv('VANTAGE_API_URL','http://localhost:8000')

def test_create_retrieve_and_issuance_gate():
    with httpx.Client(base_url=BASE,timeout=10) as c:
        payload={'app_type':'ANNUITY','applicant_name':'Synthetic Client','product_code':'DEMO-FIA','requested_amount':'25000','tax_qualification':'NON_QUALIFIED','beneficiaries':[{'name':'Synthetic Beneficiary','category':'PRIMARY','share':'100'}]}
        response=c.post('/applications',json=payload);assert response.status_code==201,response.text
        app_id=response.json()['id']
        assert c.get(f'/applications/{app_id}').json()['status']=='DRAFT'
        assert c.post(f'/applications/{app_id}/transition',params={'target':'ISSUED'}).status_code==409
        assert c.post(f'/applications/{app_id}/transition',params={'target':'SUBMITTED'}).status_code==200
        assert c.post(f'/applications/{app_id}/transition',params={'target':'IN_REVIEW'}).status_code==200
        assert c.post(f'/applications/{app_id}/transition',params={'target':'APPROVED'}).status_code==409
        assert c.post(f'/applications/{app_id}/decisions',json={'decision_type':'SUITABILITY','approved':True}).status_code==200
        assert c.post(f'/applications/{app_id}/transition',params={'target':'APPROVED'}).status_code==200
        assert c.post(f'/applications/{app_id}/transition',params={'target':'ISSUED'}).status_code==409
        assert c.post(f'/applications/{app_id}/decisions',json={'decision_type':'FUNDING','approved':True}).status_code==200
        assert c.post(f'/applications/{app_id}/transition',params={'target':'ISSUED'}).status_code==200

def test_event_idempotency():
    with httpx.Client(base_url=BASE,timeout=10) as c:
        event={'source_system':'CRM','external_event_id':str(uuid.uuid4()),'event_type':'CUSTOMER_UPDATED','payload':{'synthetic':True}}
        assert c.post('/integrations/events',json=event).json()['status']=='accepted'
        assert c.post('/integrations/events',json=event).json()['status']=='duplicate_ignored'
