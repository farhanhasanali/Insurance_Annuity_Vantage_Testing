-- Run after tests/fixture load. Queries return violations; zero rows = pass.
SELECT 'INVALID_PRIMARY_SHARES' AS defect, application_id, SUM(share_pct) AS actual
FROM beneficiaries WHERE beneficiary_class='PRIMARY' GROUP BY application_id HAVING SUM(share_pct)<>100;
SELECT 'ISSUED_WITHOUT_GATE' AS defect,id FROM applications WHERE status='ISSUED' AND NOT funding_verified;
SELECT 'DUPLICATE_SOURCE_EVENT' AS defect, source_system,external_event_id,COUNT(*) FROM inbound_events GROUP BY 1,2,3 HAVING COUNT(*)>1;
SELECT 'UNVERIFIED_ISSUED_PREMIUM' AS defect,a.id FROM applications a JOIN premium_sources p ON p.application_id=a.id WHERE a.status='ISSUED' AND NOT p.verified;
